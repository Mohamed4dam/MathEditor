(function ($, Quill) {
  $(document).ready(() => {
    main();
  });
})(window.jQuery, window.Quill);

function main() {
  Quill.register("modules/formula", mathquill4quill);
  Quill.register("modules/pagination", Pagination);
  // Initialize Quill editor
  const quill = new Quill("#editor", {
    theme: "snow",
    placeholder:
      "\t\t\t\t\t  Your name here...\n" +
      "\t\t\t\t\t  Instructor name here...\n" +
      "\t\t\t\t\t  Course here...\n" +
      "\t\t\t\t\t  Date here...\n",
    modules: {
      formula: true,
      pagination: {
        userText: "Page {page}", // {page} is replaced with the number of pages
        autoText: "{page}",
        pageHeight: "279.4mm", // page height of the wrapped line
      },
      toolbar: {
        container: [
          [{ font: [] }, { size: [] }], // Font and size dropdowns
          ["bold", "italic", "underline", "strike"], // Text styling buttons
          [{ color: [] }, { background: [] }], // Color and background
          [{ list: "ordered" }, { list: "bullet" }], // Lists
          ["clean"], // Clear formatting button
          ["formula"], // Formula button
          // ["pagination"],
        ],
      },
    },
  });

  var enableMathQuillFormulaAuthoring = mathquill4quill();
  enableMathQuillFormulaAuthoring(quill, {
    operators: [
      ["\\pm", "\\pm"],
      ["\\sqrt{x}", "\\sqrt"],
      ["\\sqrt[3]{x}", "\\sqrt[3]{}"],
      ["\\sqrt[n]{x}", "\\nthroot"],
      ["\\frac{x}{y}", "\\frac"],
      ["\\sum^{s}_{x}{d}", "\\sum"],
      ["\\prod^{s}_{x}{d}", "\\prod"],
      ["\\coprod^{s}_{x}{d}", "\\coprod"],
      ["\\int^{s}_{x}{d}", "\\int"],
      ["\\binom{n}{k}", "\\binom"],
    ],
  });

  var newDocButton = addButtonToToolbar(
    quill,
    "ql-textbtn ql-newdoc",
    "New Document"
  );
  // Function to create a new document (clear the editor) with confirmation
  newDocButton.addEventListener("click", function () {
    const confirmClear = confirm(
      "Are you sure you want to create a new document? This will remove all previous content."
    );

    if (confirmClear) {
      quill.setContents([]); // Clears the editor
    } else {
      // Abort the operation
      console.log("New document creation aborted.");
    }
  });
  
  var btnPrint = addButtonToToolbar(
    quill,
    "ql-textbtn ql-print",
    "Print"
  );
  btnPrint.addEventListener("click", function() {
    window.print();
  });

  var btnPlaceholder = addButtonToToolbar(
    quill,
    "ql-textbtn ql-placeholder",
    "Show/Hide Placeholder"
  );
  // Function to create a new document (clear the editor) with confirmation
  btnPlaceholder.addEventListener("click", function () {
    if (document.getElementsByClassName("ql-editor")[0].dataset.placeholder)
      document.getElementsByClassName("ql-editor")[0].dataset.placeholder = "";
    else
      document.getElementsByClassName("ql-editor")[0].dataset.placeholder =
        "\t\t\t\t\t  Your name here...\n" +
        "\t\t\t\t\t  Instructor name here...\n" +
        "\t\t\t\t\t  Course here...\n" +
        "\t\t\t\t\t  Date here...\n";
  });
}

function addButtonToToolbar(quill, btn_class, btn_innerHTML) {
  // Add New Document Button to the toolbar dynamically
  const toolbar = quill.getModule("toolbar");
  // Create Span
  const newBtnContainer = document.createElement("span");
  newBtnContainer.className = "ql-formats";
  // Create Button
  const newBtnButton = document.createElement("button");
  newBtnButton.innerHTML = btn_innerHTML;
  newBtnButton.className = btn_class; // Match other button styles
  // Add Button to Span, then Span to Toolbar
  newBtnContainer.appendChild(newBtnButton);
  toolbar.container.appendChild(newBtnContainer);

  return newBtnButton;
}
