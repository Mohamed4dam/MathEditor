import Module from "./module.js";
import Format from "./format.js";

export { Module as Pagination, Format as PageBreak };

window.Pagination = Module;
window.PageBreak = Format;
