// Print functionality for LiTex Editor
const setupPrintButton = () => {
  // Check if print button already exists to prevent duplicates
  const existingPrintButton = document.querySelector('.ql-print');
  if (existingPrintButton) {
    return; // Exit if button already exists
  }

  // Create print button and add to toolbar
  const toolbar = document.querySelector('.ql-toolbar');
  const printContainer = document.createElement('span');
  printContainer.className = 'ql-formats';
    
  const printButton = document.createElement('button');
  printButton.innerHTML = 'Print';
  printButton.className = 'ql-print';
  
  printContainer.appendChild(printButton);
  toolbar.appendChild(printContainer);
  
  // Create and inject print styles if they don't exist
  if (!document.querySelector('#print-styles')) {
    const printStyles = document.createElement('style');
    printStyles.id = 'print-styles';
    printStyles.textContent = `
            @media print {
                @page {
                    size: 8.5in 11in;
                    margin: 0;
                }
                html, body {
                    width: 8.5in;
                    height: 11in;
                    margin: 0 !important;
                    padding: 0 !important;
                    background: white;
                }
                .editor-page {
                    page-break-after: always;
                    background: white;
                }
                .editor-page:last-child {
                    page-break-after: avoid;
                }
                .ql-editor {
                    padding: 1in !important;
                }
                .ql-toolbar, .no-print {
                    display: none !important;
                }
        }
        `;
    document.head.appendChild(printStyles);
  }
  
  const handlePrint = (e) => {
    if (e) {
      e.preventDefault();
    }
    
    // Create a hidden iframe for printing
    const printFrame = document.createElement('iframe');
    printFrame.style.position = 'fixed';
    printFrame.style.right = '0';
    printFrame.style.bottom = '0';
    printFrame.style.width = '0';
    printFrame.style.height = '0';
    printFrame.style.border = 'none';
    document.body.appendChild(printFrame);

    // Get the iframe's document
    const frameDoc = printFrame.contentDocument || printFrame.contentWindow.document;

    // Write the print content
    frameDoc.write('<html><head>');
        
    // Copy all stylesheets from the main document
    document.querySelectorAll('link[rel="stylesheet"]').forEach(styleSheet => {
      frameDoc.write(styleSheet.outerHTML);
    });
        
    // Copy all style elements
    document.querySelectorAll('style').forEach(style => {
      frameDoc.write(style.outerHTML);
    });
        
    frameDoc.write('</head><body>');

    // Get all editor pages
    const pages = document.querySelectorAll('.editor-page');
        
    // Clone content for printing
    pages.forEach(page => {
      const editorContent = page.querySelector('.ql-editor');
      if (editorContent) {
        const pageClone = document.createElement('div');
        pageClone.className = 'editor-page';
               
        const containerClone = document.createElement('div');
        containerClone.className = 'ql-container ql-snow';
                
        const contentClone = document.createElement('div');
        contentClone.className = 'ql-editor';
        contentClone.innerHTML = editorContent.innerHTML;
                
        containerClone.appendChild(contentClone);
        pageClone.appendChild(containerClone);
                
        frameDoc.body.appendChild(pageClone);
      }
    });

    frameDoc.write('</body></html>');
    frameDoc.close();

    // Wait for resources to load
    printFrame.onload = () => {
      printFrame.contentWindow.focus();
      printFrame.contentWindow.print();
            
      // Remove the iframe after printing
      setTimeout(() => {
        document.body.removeChild(printFrame);
      }, 1000);
    };
        
    return false;
  };
  
  // Handle print button click
  printButton.addEventListener('click', handlePrint);
  
  // Handle Ctrl+P
  const handleKeydown = (e) => {
    if ((e.ctrlKey || e.metaKey) && e.key === 'p') {
      handlePrint(e);
    }
  };
    
  // Remove existing listener if any
  document.removeEventListener('keydown', handleKeydown);
  // Add new listener
  document.addEventListener('keydown', handleKeydown);
};
  
// Initialize print functionality when document is loaded
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', setupPrintButton);
} else {
  setupPrintButton();
}