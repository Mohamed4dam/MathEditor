module.exports = [
  {
    ignores: ["node_modules"],
    languageOptions: {
      ecmaVersion: 2022,
      sourceType: "module"
    },
    rules: {
      indent: ["error", 2],
    },
  },
];
