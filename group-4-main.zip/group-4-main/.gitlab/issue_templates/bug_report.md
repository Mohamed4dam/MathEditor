## Bug Report

### Description
<!-- Add a brief description of the bug. -->

### Environment
<!-- Describe the environment, such as browser used. -->

### Steps to Reproduce
<!-- Add steps to reproduce the bug here. -->

1. Step 1
2. Step 2
3. Step 3

### Expected Behavior
<!-- Describe what should be happening. -->

### Actual Behavior
<!-- Describe what is actually happening. -->

### Screenshots or Logs
<!-- Provide screenshots or logs if available. -->

### Workaround
<!-- Describe a workaround to the bug if available. >