import re
from playwright.sync_api import Page, expect


def test_has_title(page: Page):
    page.goto('http://localhost:8080')
    expect(page).to_have_title(re.compile("Math Editor"))


def assert_no_errors(msg):
    assert msg.type == "error", f"Console error detected: {msg.text}"


def test_no_errors(page: Page):
    console_errors = []
    page.on(
        "console",
        lambda msg: console_errors.append(msg) if msg.type == "error" else None
        )
    page.goto('http://localhost:8080')
    assert (
        not console_errors
        ), f"Console errors detected: {[msg.text for msg in console_errors]}"
