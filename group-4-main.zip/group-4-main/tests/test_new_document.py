from playwright.sync_api import Page


def test_new_document_accept(page: Page):
    page.on("dialog", lambda dialog: dialog.accept())
    page.goto('http://localhost:8080')
    page.get_by_role("button", name="New Document").click()
    # Strip whitespace before asserting editor is empty.
    editor_content = page.locator("div.ql-editor").inner_text().strip()
    assert (
        editor_content == ""
    ), "Editor is not empty after clicking OK in new document button."


def test_new_document_cancel(page: Page):
    page.on("dialog", lambda dialog: dialog.dismiss())
    page.goto('http://localhost:8080')
    editor_content_before = page.locator("div.ql-editor").inner_text()
    page.get_by_role("button", name="New Document").click()
    editor_content_after = page.locator("div.ql-editor").inner_text()
    assert (
        editor_content_before == editor_content_after
    ), "Editor content is not the same after cancelling new document."
