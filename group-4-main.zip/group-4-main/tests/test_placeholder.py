from playwright.sync_api import Page


def test_hide_placeholder(page: Page):
    page.goto('http://localhost:8080')
    placeholder_button = page.get_by_role(
        "button", name="Show/Hide Placeholder")
    placeholder_button.click()
    # Wait at most three seconds for placeholder to disappear.
    page.wait_for_selector(
        "div.ql-editor[data-placeholder='']", timeout=3000)


def test_display_placeholder(page: Page):
    page.goto('http://localhost:8080')
    placeholder_value_before = page.get_attribute(
        "div.ql-editor", "data-placeholder")
    placeholder_button = page.get_by_role(
        "button", name="Show/Hide Placeholder")
    placeholder_button.click()
    placeholder_button.click()
    placeholder_value_after = page.get_attribute(
        "div.ql-editor", "data-placeholder")
    assert (
        placeholder_value_before == placeholder_value_after
    ), "Placeholder text is not correct"
