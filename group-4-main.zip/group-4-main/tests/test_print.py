from playwright.sync_api import Page


def test_print(page: Page):
    page.goto('http://localhost:8080')

    # Mock the window.print function
    page.evaluate("""
        window.print = () => {
            console.log('Print dialog triggered');
        }
    """)

    # Check that 'Print' button called mock print function.
    logs = []
    page.on("console", lambda msg: logs.append(msg.text))
    page.get_by_role("button", name="Print").click()
    page.wait_for_timeout(100)
    assert any(
        "Print dialog triggered" in log for log in logs
        ), "Print dialog was not triggered"


def test_print_media_styles(page: Page):
    page.goto('http://localhost:8080')
    page.emulate_media(media="print")
    assert page.evaluate(
        "matchMedia('print').matches"
        ), "Print media styles are not applied"
